const showHeader = () => {
  const headerData = JSON.parse(headers);
  const tableRef = document.getElementById("main_table");
  let tableHeader = "<tr>";
  tableHeader += "<td><input type='checkbox' class=&quot;checkbox&quot;/></td>";
  headerData.forEach(element => {
    tableHeader += "<th>" + element + "</th>";
  });
  tableHeader += "</tr>";
  tableRef.innerHTML += tableHeader;
}

const showOnLoad = () => {
  showHeader();
  const tableData = JSON.parse(data);
  const tableRef = document.getElementById("main_table");
  tableData.forEach(tableRow => {
    let tableEle = "<tr>";
    tableEle += "<td><input type='checkbox' class=&quot;checkbox&quot;/></td>";
    Object.entries(tableRow).forEach(tableRowEle => {
      const [key,value] = tableRowEle;
      tableEle += "<td>" + value + "</td>";
    })
    tableEle += "</tr>";
    tableRef.innerHTML += tableEle;
  });

  document.getElementById('addbtn').addEventListener('click',
  function() {
    document.querySelector('.bg-modal').style.display = 'flex';
  });

  document.getElementById('editbtn').addEventListener('click',
  function() {
    document.querySelector('.bg-modal2').style.display = 'flex';
  });

  document.getElementById('deletebtn').addEventListener('click',
  function() {
    document.querySelector('.bg-modal3').style.display = 'flex';
  });

  document.getElementById('cancel_button').addEventListener('click',
  function() {
    document.querySelector('.bg-modal').style.display = 'none';
  });

  document.getElementById('cancel_button2').addEventListener('click',
  function() {
    document.querySelector('.bg-modal2').style.display = 'none';
  });

  document.getElementById('cancel_button3').addEventListener('click',
  function() {
    document.querySelector('.bg-modal3').style.display = 'none';
  });

  document.getElementById('popupaddbtn').addEventListener('click',
function(){
  const custname = document.getElementById("custname_ip").value;
  const custnum = document.getElementById("custnum_ip").value;
  const invnum = document.getElementById("invnum_ip").value;
  const invamt = document.getElementById("invamt_ip").value;
  const duedate = document.getElementById("duedate_ip").value;
  const notes = document.getElementById("notes_ip").value;
  const tableRef = document.getElementById("main_table");
  tableRef.innerHTML += `<tr><td><input type='checkbox' class=&quot;checkbox&quot;/></td><td>${custname}</td><td>${custnum}</td><td>${invnum}</td><td>${invamt}</td><td>${duedate}</td><td>${notes}</td></tr>`
});
}
//
// const add() = () => {
//   const custname = document.getElementById("custname_ip").value;
//   const custnum = document.getElementById("custnum_ip").value;
//   const invnum = document.getElementById("invnum_ip").value;
//   const invamt = document.getElementById("invamt_ip").value;
//   const duedate = document.getElementById("duedate_ip").value;
//   const notes = document.getElementById("notes_ip").value;
//   const tableRef = document.getElementById("main_table");
//   tableRef.innerHTML += `<tr><td>${custname}</td><td>${custnum}</td><td>${invnum}</td><td>${invamt}</td><td>${duedate}</td><td>${notes}</td></tr>`
// }
